package gestionEmprunt;

import gestionDocument.*;
import java.util.*;
import gestionDocument.Exemplaire;

public class Emprunt 
{
    public String dateDeb;
    public String getDateDeb () {
        return this.dateDeb;
    }

    public String dateFin;
    public String getDateFin () {
        return this.dateFin;
    }

    public Exemplaire exemplaire;
    public Exemplaire getExemplaire () {
        return this.exemplaire;
    }
    public int cardExemplaire () {
        if ( this.exemplaire == null ) return 0;
        else return 1;
    }


    public boolean verifier()
    {
return true;
    }
}
