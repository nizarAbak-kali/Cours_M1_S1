package gestionEmprunt;

import gestionDocument.*;
import java.util.*;
import java.util.Vector;

public class Utilisateur 
{
    public String cat�gorie;
    public String getCat�gorie () {
        return this.cat�gorie;
    }

    public Vector emprunts;
    public Vector getEmprunts () {
        return this.emprunts;
    }
    public int cardEmprunts () {
        if ( this.emprunts == null ) return 0;
        else return 1;
    }

    public String id;
    public String getId () {
        return this.id;
    }

}
