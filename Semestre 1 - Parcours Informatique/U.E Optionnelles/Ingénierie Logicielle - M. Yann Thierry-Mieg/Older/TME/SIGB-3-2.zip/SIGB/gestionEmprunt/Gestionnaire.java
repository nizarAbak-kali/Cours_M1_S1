package gestionEmprunt;

import gestionDocument.*;
import java.util.*;
import java.util.Vector;

public class Gestionnaire 
{
    private static Gestionnaire _instance;
    public static Gestionnaire get_instance () {
        return Gestionnaire._instance;
    }
    public static void set_instance (Gestionnaire value) {
        Gestionnaire._instance = value; 
    }
    public static int card_instance () {
        if ( Gestionnaire._instance == null ) return 0;
        else return 1;
    }

    public Vector utilisateurs;
    public Vector getUtilisateurs () {
        return this.utilisateurs;
    }
    public int cardUtilisateurs () {
        if ( this.utilisateurs == null ) return 0;
        else return 1;
    }

    public Vector emprunt;
    public Vector getEmprunt () {
        return this.emprunt;
    }
    public int cardEmprunt () {
        if ( this.emprunt == null ) return 0;
        else return 1;
    }


    private Gestionnaire()
    {
    	utilisateurs = new Vector();
    	emprunt = new Vector();
    }

    public Emprunt enregistrerEmprunt(
        String idExemplaire,
        String idUtilisateur)
    {
//Chercher utilisateur
		Utilisateur util = chercherUtilisateur(idExemplaire);
		if (util != null) {
			//V�rifier les emprunts de l'utilisateur
			java.util.Vector emprunts = util.getEmprunts();
			for (java.util.Enumeration e = emprunts.elements(); e
					.hasMoreElements();) {
				if (!((Emprunt) e.nextElement()).verifier())
					return null;
			}
			//V�rifier l'�tat de l'utilisateur
			if (util.getCat�gorie().compareTo("interdit") == 0)
				return null;
			//Ok pour l'emprunt
			Emprunt ne = new Emprunt();
			ne.dateDeb = "today";
			ne.dateFin = "tomorrow";
			util.getEmprunts().add(ne);
			emprunt.add(ne);
			return ne;
		} else
			return null;
    }

    public void enregistrerRetour(
        String idExemplaire)
    {
    }

    public void prolongerEmprunt(
        String idExemplaire)
    {
    }

    public void interdireUtilisateur(
        String idUtilisateur)
    {
chercherUtilisateur(idUtilisateur).cat�gorie = "interdit";
    }

    public static Gestionnaire Instance()
    {
// THIS IS DESIGN PATTERNS AUTOMATICALLY GENERATED CODE. DON'T TOUCH PLEASE!
if (get_instance() == null) {
    set_instance(new Gestionnaire());
}
// END OF DESIGN PATTERNS AUTOMATICALLY GENERATED CODE.
// THIS IS DESIGN PATTERNS AUTOMATICALLY GENERATED CODE. DON'T TOUCH PLEASE!
return get_instance();
// END OF DESIGN PATTERNS AUTOMATICALLY GENERATED CODE.
    }

    private Utilisateur chercherUtilisateur(
        String id)
    {
for (java.util.Enumeration e = utilisateurs.elements() ; e.hasMoreElements() ; ) {
    		Utilisateur current = (Utilisateur) e.nextElement();
    		if (current.getId().compareTo(id)==0) return current;
    	}
    	    return null;
    }
}
