package gestionDocument;

import java.util.*;

public class Exemplaire 
{
    public Document document;
    public Document getDocument () {
        return this.document;
    }
    public int cardDocument () {
        if ( this.document == null ) return 0;
        else return 1;
    }

    public String id;
    public String getId () {
        return this.id;
    }

    public String statut;
    public String getStatut () {
        return this.statut;
    }

    public String etat;
    public String getEtat () {
        return this.etat;
    }

}
