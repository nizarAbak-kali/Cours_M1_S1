package gestionDocument;

import java.util.*;

public class P�riodique 
    extends Document
{
    public String volume;
    public String getVolume () {
        return this.volume;
    }

    public String numero;
    public String getNumero () {
        return this.numero;
    }

    public String ISSN;
    public String getISSN () {
        return this.ISSN;
    }

}
