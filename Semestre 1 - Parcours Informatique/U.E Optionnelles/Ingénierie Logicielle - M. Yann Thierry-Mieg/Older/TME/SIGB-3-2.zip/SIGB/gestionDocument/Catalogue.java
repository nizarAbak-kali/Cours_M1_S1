package gestionDocument;

import java.util.*;
import java.util.Vector;

public class Catalogue 
{
    Vector exemplaires;
    public Vector getExemplaires () {
        return this.exemplaires;
    }
    public int cardExemplaires () {
        if ( this.exemplaires == null ) return 0;
        else return 1;
    }


    public Exemplaire rechercherExemplaireParId(
        String id)
    {
for (java.util.Enumeration e = exemplaires.elements() ; e.hasMoreElements() ; ) {
	Exemplaire current = (Exemplaire) e.nextElement();
	if (current.getId().compareTo(id)==0) return current;
}
    return null;
    }
}
