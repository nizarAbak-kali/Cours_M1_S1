package gestionDocument;

import java.util.*;

public class Livre 
    extends Document
{
    public String auteur;
    public String getAuteur () {
        return this.auteur;
    }

    public String ISBN;
    public String getISBN () {
        return this.ISBN;
    }

}
