package gestionDocument;

import java.util.*;

public class Document 
{
    public String titre;
    public String getTitre () {
        return this.titre;
    }

    public String anneePublication;
    public String getAnneePublication () {
        return this.anneePublication;
    }

    public String editeur;
    public String getEditeur () {
        return this.editeur;
    }

    public String ref;
    public String getRef () {
        return this.ref;
    }

}
