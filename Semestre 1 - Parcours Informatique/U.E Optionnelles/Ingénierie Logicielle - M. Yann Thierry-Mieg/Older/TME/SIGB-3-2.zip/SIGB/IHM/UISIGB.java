package IHM;

import gestionEmprunt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UISIGB 
{

    public static void main(
        String[] args)
    {
UIControler.Instance();
    }
}
