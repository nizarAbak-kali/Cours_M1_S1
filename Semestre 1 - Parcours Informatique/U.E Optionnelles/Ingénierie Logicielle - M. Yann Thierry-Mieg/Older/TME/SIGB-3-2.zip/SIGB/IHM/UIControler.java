package IHM;

import gestionEmprunt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;

public class UIControler 
    extends JFrame
{
    private static UIControler _instance;
    public static UIControler get_instance () {
        return UIControler._instance;
    }
    public static void set_instance (UIControler value) {
        UIControler._instance = value; 
    }
    public static int card_instance () {
        if ( UIControler._instance == null ) return 0;
        else return 1;
    }


    private UIControler()
    {
    	super("Mon Repertoire");
		WindowListener l = new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		};
		addWindowListener(l);
		afficherEcran("Accueil");
		setVisible(true);
		pack();
    }

    public void afficherEcran(
        String ecran)
    {
    	JPanel pan = null;
    	if (ecran.compareTo("Accueil")==0){
    		Accueil acc = new Accueil();
    		acc.init();
    		pan = acc;
    	}
    	else if (ecran.compareTo("Emprunt")==0){
    		EnregistrerEmprunt emp = new EnregistrerEmprunt();
    		emp.init();
    		pan = emp;
    		
    	}
    	if (pan!=null) {
    		getContentPane().removeAll();
    		getContentPane().add(pan);
    		pack();
    	}
    }

    public static UIControler Instance()
    {
// THIS IS DESIGN PATTERNS AUTOMATICALLY GENERATED CODE. DON'T TOUCH PLEASE!
if (get_instance() == null) {
    set_instance(new UIControler());
}
// END OF DESIGN PATTERNS AUTOMATICALLY GENERATED CODE.
// THIS IS DESIGN PATTERNS AUTOMATICALLY GENERATED CODE. DON'T TOUCH PLEASE!
return get_instance();
// END OF DESIGN PATTERNS AUTOMATICALLY GENERATED CODE.
    }
}
