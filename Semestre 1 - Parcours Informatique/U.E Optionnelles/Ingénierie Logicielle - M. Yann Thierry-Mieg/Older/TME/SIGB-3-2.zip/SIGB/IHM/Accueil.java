package IHM;

import gestionEmprunt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import IHM.EnregistrerEmprunt;
import IHM.EnregistrerRetour;
import IHM.ProlongerEmprunt;
import IHM.InterdireUtilisateur;

public class Accueil 
    extends JPanel
{
    public JButton enregistrement;
    public JButton getEnregistrement () {
        return this.enregistrement;
    }

    public JButton retour;
    public JButton getRetour () {
        return this.retour;
    }

    public JButton prolonger;
    public JButton getProlonger () {
        return this.prolonger;
    }

    public JButton interdire;
    public JButton getInterdire () {
        return this.interdire;
    }


    public void boutonEnregistrerEmprunt()
    {
    	UIControler.Instance().afficherEcran("Emprunt");
    }

    public void boutonEnregistrerRetour()
    {
    }

    public void boutonProlongerEmprunt()
    {
    }

    public void boutonInterdireUtilisateur()
    {
    }

    public void init()
    {
    	this.setLayout(new GridLayout(0, 1));
    	enregistrement = new JButton();
    	enregistrement.setLabel("enregistrement");
    	enregistrement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boutonEnregistrerEmprunt();
			}
		});
    	add(enregistrement);
    	
    	retour = new JButton();
    	retour.setLabel("retour");
    	retour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boutonEnregistrerRetour();
			}
		});
    	add(retour);
    	
    	prolonger = new JButton();
    	prolonger.setLabel("prolonger");
    	prolonger.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boutonProlongerEmprunt();
			}
		});
    	add(prolonger);
    	
    	interdire = new JButton();
    	interdire.setLabel("interdire");
    	interdire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boutonInterdireUtilisateur();
			}
		});
    	add(interdire);
    }
}
