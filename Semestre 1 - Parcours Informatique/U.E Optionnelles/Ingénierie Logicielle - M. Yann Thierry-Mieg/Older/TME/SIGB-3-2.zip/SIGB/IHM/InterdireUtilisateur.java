package IHM;

import gestionEmprunt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import gestionEmprunt.Gestionnaire;
import javax.swing.JButton;
import javax.swing.JTextField;

public class InterdireUtilisateur 
    extends JPanel
{
    public JButton interdire;
    public JButton getInterdire () {
        return this.interdire;
    }

    public JTextField idUtilisateur;
    public JTextField getIdUtilisateur () {
        return this.idUtilisateur;
    }


    public void interdireUtilisateur()
    {
    }

    public void init()
    {
    }
}
