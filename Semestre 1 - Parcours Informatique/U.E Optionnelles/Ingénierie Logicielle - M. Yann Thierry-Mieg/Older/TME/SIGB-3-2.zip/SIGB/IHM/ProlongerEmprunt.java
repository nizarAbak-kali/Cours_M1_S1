package IHM;

import gestionEmprunt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import gestionEmprunt.Gestionnaire;
import javax.swing.JTextField;
import javax.swing.JButton;

public class ProlongerEmprunt 
    extends JPanel
{
    public JTextField idExemaplaire;
    public JTextField getIdExemaplaire () {
        return this.idExemaplaire;
    }

    public JButton valider;
    public JButton getValider () {
        return this.valider;
    }


    public void validerProlongation()
    {
    }

    public void init()
    {
    }
}
