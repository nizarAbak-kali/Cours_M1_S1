package IHM;

import gestionEmprunt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import gestionEmprunt.Gestionnaire;
import javax.swing.JTextField;
import javax.swing.JButton;

public class EnregistrerEmprunt 
    extends JPanel
{
    public JTextField idUtilisateur;
    public JTextField getIdUtilisateur () {
        return this.idUtilisateur;
    }

    public JTextField idExemplaire;
    public JTextField getIdExemplaire () {
        return this.idExemplaire;
    }

    public JButton enregistrement;
    public JButton getEnregistrement () {
        return this.enregistrement;
    }


    public void validerEnregistremenr()
    {
Gestionnaire.Instance().enregistrerEmprunt(idExemplaire.getText(), idUtilisateur.getText());
UIControler.Instance().afficherEcran("Accueil");
    }

    public void init()
    {
this.setLayout(new GridLayout(0, 2));
    	add(new JLabel("id"));
    	idUtilisateur = new JTextField("");
    	add(idUtilisateur);
    	add(new JLabel("exemplaire"));
    	idExemplaire = new JTextField("");
    	add(idExemplaire);
    	enregistrement = new JButton();
    	enregistrement.setLabel("OK");
    	enregistrement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				validerEnregistremenr();
			}
		});
    	add(enregistrement);
    }
}
