package externe.recoImage;

import java.awt.Image;

public interface IReconnaissanceImage {

	int [][] readImage(Image image);
}
